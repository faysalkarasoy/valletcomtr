﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ValletComTR_Ornek
{
    public partial class hataliSonucWebForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //sipariş numarası
            var orderId = Request["orderId"];

            Response.Write($"{orderId}<br>ödeme başarısız !");
        }
    }
}