﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
/*
 * Dikkat bu sayfa kullanıcının başarılı işlem sonucunda yönlendirildiği sayfadır.
 * Ödeme onay durumu için;
 * mağaza bildirim sayfanıza gelen bilgileri kontrol edin.
 * örnek kodlar Vallet_CallBack.aspx sayfasında mevcuttur.
 */
namespace ValletComTR_Ornek
{
    public partial class dogruSonucWebForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /*
             Sipariş işlemini bu aşamada onaylamayın
             Vallet.com.tr den bildirim gelmesini bekleyin

            örnek kodlar Vallet_CallBack.aspx sayfasında mevcuttur
             */

            //sipariş numarası
            var orderId = Request["orderId"];

            Response.Write($"{orderId}<br>nolu sipariniz için ödeme alındı");
        }
    }
}