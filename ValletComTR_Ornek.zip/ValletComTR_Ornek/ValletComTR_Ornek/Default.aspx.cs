﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ValletComTR_Ornek
{
    public partial class SiparisWebForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void OdemeYapButton_Click(object sender, EventArgs e)
        {
            string payment_page_url = "yok";


            ValletConfig valletConfig = new ValletConfig();
            valletConfig.userName = "entegrevallet_api";
            valletConfig.password = "f7c3bc1d808e04732adf679965ccc34ca7ae3441";
            valletConfig.shopCode = "7345";
            valletConfig.hash = "pTfAQuD3";


            List<ProductData> productData = new List<ProductData>
            {
                new ProductData { productName = "Ürün adı 1", productPrice = "100", productType = "DIJITAL_URUN" },
                new ProductData { productName = "Ürün adı 2", productPrice = "25.60", productType = "DIJITAL_URUN" }
            };

            PostData postData = new PostData();
            postData.productData = productData;
            

            postData.orderId = System.Guid.NewGuid().ToString(); // "her sipariş için benzersiz order ID";

            /*bu bilgilerin https://www.vallet.com.tr/merchant/api-manager/api-information.html adresinden girilmesi lazım*/
            postData.referer = "test.com";
            
            /*kullanıcı başarılı işlem geri dönüş urlsi*/
            postData.callbackOkUrl = "https://test.com/dogruSonuc.aspx";
            
            /*kullanıcı başarısız işlem sonucunda geri dönüş*/
            postData.callbackFailUrl = "https://test.com/hataliSonuc.aspx";


            postData.buyerMail = "musteri@eposta.com";
            postData.buyerGsmNo = "+905329999999";
            postData.buyerName = "müşteri adı";
            postData.buyerSurName = "müşteri soyadı";
            postData.buyerCountry = "Türkiye";
            postData.buyerCity = "Ankara";
            postData.buyerDistrict = "Çankaya";
            postData.buyerAdress = "Müşteri açık adres";
            postData.buyerIp = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"]; //müşteri ip adresi

            postData.currency = "TRY"; //TRY,EUR,USD
            postData.locale = "tr";//en,de,ru
            

            postData.orderPrice = "125.60";
            postData.productName = "TES ÜRÜNLER";
            postData.productType = "DIJITAL_URUN";
            postData.productsTotalPrice = "125.60";
            
           



            ValletRequest valletRequest = new ValletRequest(valletConfig);

            
            var r = valletRequest.Create_payment_link(postData);
            
            var json = JValue.Parse(r.ToString());
            if (json["status"] != null && json["payment_page_url"] !=null)
            {
                payment_page_url = json["payment_page_url"].ToString();
            }

            if (payment_page_url != "yok")
            {
                //eğer işlem başarı oluşturulmuşsa kullanıcı ödeme sayfasına yönlendirilecek
                Response.Redirect(payment_page_url);

            } else {
                
                if (json["errorMessage"] != null)
                {
                    Response.Write(json["errorMessage"].ToString());

                } else {
                    Response.Write(r.ToString());
               }
            }
            



        }
    }
}