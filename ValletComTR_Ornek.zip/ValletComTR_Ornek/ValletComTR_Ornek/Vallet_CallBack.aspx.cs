﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
DİKKAT 1 : Bu örnekleri değiştirmeden yada düzenlemeden sisteminizde kullanmayın. Bu kod yapısı sadece işleyiş ve senaryolar hakkında önizleme ve bilgi edinmeniz niteliğindedir.
Post güvenliğinin sağlanması ve işleyişin ve entegrasyonun doğru bir şekilde yapılandırılması tamamen sizin sorumluluğunuzdadır.

DİKKAT 2 : Bu sayfa müşterilerinizin göreceği bir sayfa değildir.
Ödeme işlemi yapıldığında arka planda vallet servisleri ödemeyi bu sayfanıza bildirecektir.
Ödemeyi sisteminize işlediğinizde ekrana OK cevabı vermelisiniz.
Aksi bir durum yada hatada Sadece hata yada sorun ile ilgili kısa bit metin yazdırmanız yeterlidir.
*/
namespace ValletComTR_Ornek
{
    public partial class Vallet_CallBack : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("OK");

            ValletConfig valletConfig = new ValletConfig();
            valletConfig.userName = "Api kullanıcı Adı";
            valletConfig.password = "Api Şifreniz (key)";
            valletConfig.shopCode = "Aği Mağaza kodunuz";
            valletConfig.hash = "Api hash anahtarınız";


            var status = Request["status"];
            var paymentStatus = Request["paymentStatus"];
            var paymentCurrency = Request["paymentCurrency"];
            var paymentAmount = Request["paymentAmount"];

            /*
             KART, BANKA_HAVALE, YURT_DISI
             */
            var paymentType = Request["paymentType"];
            
            var paymentTime = Request["paymentTime"];
            var orderPrice = Request["orderPrice"];
            var shopCode = Request["shopCode"];

            //conversationId   gönderilmişse
            var conversationId = Request["conversationId"];


            //sipariş numarası
            var orderId = Request["orderId"];


            var productsTotalPrice = Request["productsTotalPrice"];
            var productType = Request["productType"];
            
            var callbackOkUrl = Request["callbackOkUrl"];
            var callbackFailUrl = Request["callbackFailUrl"];


            //Üretilen İmza
            var hash = Request["hash"];

            if (orderId == null || paymentCurrency == null || orderPrice == null || productsTotalPrice == null || productType == null)
            {
                Response.Write("EKSIK BİLGİ");
            } else {
            
                var hash_string = string.Concat(orderId,paymentCurrency,orderPrice,productsTotalPrice,productType,valletConfig.shopCode,valletConfig.hash);
                var MY_HASH = Hash_generate(hash_string);

                if(MY_HASH != hash)
                {
                    /*Hash Uyuşmuyor*/
                    Response.Write("HATALI_HASH_IMZASI");

                } else {

/*
paymentWait,paymentVerification, paymentOk, paymentNotPaid

paymentWait = Sipariş Ödenmemiş. Ödemeyi bekliyor. paymentOk cevabını bekleyin
paymentVerification = Tahsilat işlemi tamamlanmamış yada tahsilat inceleme beklemektedir. paymentOk cevabı alana kadar hizmetinizi satmayın
paymentOk = Tutar Müşteriden tahsil edilmiştir. Tutar hesabınıza geçmiştir.
paymentNotPaid = Sipariş Ödemesi Rededildi
*/
                    if (paymentStatus == "paymentOk") {

                        //ödeme tamamlanmıştır
                        //veritabanınızda v.s kendinize göre işlem yapın
                        //SqlCommand($"UPDATE Table_Siparis SET Odendi=1 WHERE ValletOrderId='{orderId}'")


                    }
                    else {
                        //diğer durumlar için yukarıda yer alan bilgilere göre kendinize özel kodlama yapın
                    }

                }
            }

        }


        private string Hash_generate(string text)
        {
            var sonuc = "";
            using (SHA1 sha1Hash = SHA1.Create())
            {
                byte[] sourceBytes = Encoding.UTF8.GetBytes(text);
                byte[] hashBytes = sha1Hash.ComputeHash(sourceBytes);
                sonuc = Convert.ToBase64String(hashBytes);
            }

            return sonuc;
        }

    }


}