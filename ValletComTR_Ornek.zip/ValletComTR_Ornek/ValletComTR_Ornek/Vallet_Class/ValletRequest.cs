﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace ValletComTR_Ornek
{
    public class ValletRequest
    {
        const string Api_URL = "https://www.vallet.com.tr/api/v1/create-payment-link";

        private ValletConfig _valletConfig;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="valletConfig"></param>
        public ValletRequest(ValletConfig valletConfig)
        {
           _valletConfig = valletConfig;
        }


        private string Hash_generate(string text)
        {
            var sonuc = "";
            string Birlestir = string.Concat(_valletConfig.userName,_valletConfig.password,_valletConfig.shopCode,text,_valletConfig.hash);
            using (SHA1 sha1Hash = SHA1.Create()) {
                byte[] sourceBytes = Encoding.UTF8.GetBytes(Birlestir);
                byte[] hashBytes = sha1Hash.ComputeHash(sourceBytes);
                sonuc = Convert.ToBase64String(hashBytes);
            }

            return sonuc;
        }

        public object Create_payment_link(PostData post_data)
        {
            post_data.userName = _valletConfig.userName;
            post_data.password = _valletConfig.password;
            post_data.shopCode = _valletConfig.shopCode;

            post_data.hash = Hash_generate(post_data.orderId + post_data.currency + post_data.orderPrice + post_data.productsTotalPrice + post_data.productType + post_data.callbackOkUrl + post_data.callbackFailUrl);

            var Response = Send_post(post_data);

            return Response;
        }

        private object Send_post(PostData post_data)
        {

            object Result;

            NameValueCollection data = new NameValueCollection();
            data["userName"] = post_data.userName;
            data["password"] = post_data.password;
            data["shopCode"] = post_data.shopCode;
            data["productName"] = post_data.productName;
            data["productType"] = post_data.productType;
            data["productsTotalPrice"] = post_data.productsTotalPrice.ToString();
            data["orderPrice"] = post_data.orderPrice.ToString();
            data["currency"] = post_data.currency;
            data["orderId"] = post_data.orderId;
            data["locale"] = post_data.locale;
            data["conversationId"] = post_data.conversationId;
            data["buyerName"] = post_data.buyerName;
            data["buyerSurName"] = post_data.buyerSurName;
            data["buyerGsmNo"] = post_data.buyerGsmNo;
            data["buyerIp"] = post_data.buyerIp;
            data["buyerMail"] = post_data.buyerMail;
            data["buyerAdress"] = post_data.buyerAdress;
            data["buyerCountry"] = post_data.buyerCountry;
            data["buyerCity"] = post_data.buyerCity;
            data["buyerDistrict"] = post_data.buyerDistrict;
            data["callbackOkUrl"] = post_data.callbackOkUrl;
            data["callbackFailUrl"] = post_data.callbackFailUrl;
            data["module"] = "NATIVE_NET";
            data["hash"] = post_data.hash;
            data["productData"] = JsonConvert.SerializeObject(post_data.productData);




            using (WebClient client = new WebClient())
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                
                client.Headers.Add("Referer", post_data.referer);
                client.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
                byte[] uploadresult = client.UploadValues(Api_URL, "POST", data);
                Result  = Encoding.UTF8.GetString(uploadresult);

            }

        
            return Result;
        }
    }

}